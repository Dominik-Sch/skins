<?php

$EM_CONF[$_EXTKEY] = array(
    'title' => 'Typo3 Skins',
    'description' => 'This extension add a dark skin to the Typo3 backend.',
    'category' => 'be',
    'author' => 'Dominik Schüßler',
    'author_company' => '',
    'author_email' => 'dominikschuessler1337@gmail.com',
    'dependencies' => '',
    'state' => 'stable',
    'clearCacheOnLoad' => '1',
    'version' => '10.4.15.1',
    'constraints' => array(
        'depends' => array(
            'typo3' => '10.4.0-10.4.99',
        )
    )
);
