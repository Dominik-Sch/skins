#
# Table structure for table 'be_users'
#
CREATE TABLE be_users (

  tx_skins_darkmode int(1) DEFAULT 0 NOT NULL,

);